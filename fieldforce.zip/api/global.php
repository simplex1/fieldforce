<?php
  if( ! ini_get('date.timezone') ){date_default_timezone_set('GMT');}
  if(!defined("BASEPATH")){define("BASEPATH",'c:/webjobs/fieldforce');}
?>